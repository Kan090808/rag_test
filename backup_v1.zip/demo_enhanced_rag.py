#!/usr/bin/env python3
"""
Demo script for enhanced RAG functionality with Letstalk-specific queries
Tests query expansion and multi-stage retrieval with relevant queries
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from rag_agent import RAGAgent
import config

def demo_enhanced_rag():
    """Demo the enhanced RAG functionality with Letstalk-relevant queries"""
    
    print("=" * 70)
    print("Enhanced RAG Demo - Query Expansion & Multi-stage Retrieval")
    print("=" * 70)
    
    # Initialize RAG agent
    agent = RAGAgent(
        openrouter_api_key=config.OPENROUTER_API_KEY,
        model_name=config.MODEL_NAME,
        max_tokens=config.MAX_TOKENS,
        temperature=config.TEMPERATURE,
        log_file="demo_enhanced_rag_log.txt",
        system_prompt=config.SYSTEM_PROMPT
    )
    agent.default_top_k = 3  # Use 3 for demo
    
    # Load embeddings
    if not agent.load_embeddings():
        print("請先運行 setup_rag.py 創建 embeddings")
        return
    
    print(f"\n✅ 已加載 {len(agent.documents)} 個文檔")
    
    # Demo different query types and show the enhancement
    demo_cases = [
        {
            "category": "極短查詢 (1-2字) - 使用字符匹配搜索",
            "queries": [
                "群",      # About groups
                "好友",    # About friends  
                "訊息",    # About messages
            ]
        },
        {
            "category": "短查詢 (3-5字) - 查詢擴展 + 語義搜索",
            "queries": [
                "登入問題",
                "傳送檔案", 
                "群組功能",
                "帳號設定"
            ]
        },
        {
            "category": "中長查詢 - 完整語義匹配",
            "queries": [
                "如何建立群組聊天",
                "忘記密碼怎麼辦",
                "圖片無法下載"
            ]
        }
    ]
    
    for case in demo_cases:
        print(f"\n{'='*50}")
        print(f"📋 {case['category']}")
        print('='*50)
        
        for query in case['queries']:
            print(f"\n🔍 查詢: '{query}'")
            print(f"   查詢長度: {len(query)} 字符")
            
            # Show query expansion
            expanded_query = agent.expand_query(query)
            if expanded_query != query:
                print(f"   ✨ 查詢擴展: {expanded_query}")
            else:
                print(f"   ➡️  未進行查詢擴展")
            
            # Retrieve documents
            relevant_docs = agent.retrieve_relevant_documents(query, top_k=3)
            
            if relevant_docs:
                print(f"   📊 找到 {len(relevant_docs)} 個相關文檔:")
                for i, doc in enumerate(relevant_docs, 1):
                    similarity = doc['similarity']
                    question = doc['metadata']['question']
                    
                    # Truncate long questions for display
                    if len(question) > 60:
                        question = question[:60] + "..."
                    
                    print(f"      {i}. 相似度: {similarity:.4f}")
                    print(f"         問題: {question}")
            else:
                print("   ❌ 未找到相關文檔")
            
            print(f"   {'-'*40}")
    
    # Interactive demo
    print(f"\n{'='*70}")
    print("🎯 互動演示 - 完整對話功能")
    print("='*70")
    print("輸入查詢來測試完整的RAG對話功能")
    print("輸入 'quit' 或 'exit' 結束演示")
    print("='*70")
    
    while True:
        try:
            user_query = input("\n👤 您的問題: ").strip()
            
            if user_query.lower() in ['quit', 'exit', '退出', 'q']:
                print("👋 演示結束，感謝使用！")
                break
                
            if not user_query:
                continue
            
            print(f"\n🤖 正在分析查詢: '{user_query}'")
            
            # Show the enhancement process
            expanded_query = agent.expand_query(user_query)
            if expanded_query != user_query:
                print(f"   ✨ 查詢已擴展")
            
            # Get response
            response = agent.chat(user_query)
            print(f"\n🤖 阿萊Eli: {response}")
            
        except KeyboardInterrupt:
            print("\n\n👋 演示結束，感謝使用！")
            break
        except Exception as e:
            print(f"❌ 錯誤: {e}")

if __name__ == "__main__":
    demo_enhanced_rag()
