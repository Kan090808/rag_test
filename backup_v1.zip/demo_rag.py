#!/usr/bin/env python3
"""
Demo script for RAG Agent
This script demonstrates how to use the RAG agent with example queries.
"""

import os
import sys

# Add current directory to path to import our modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def demo_rag_agent():
    """Demonstrate RAG agent functionality"""
    
    try:
        from rag.rag_agent import RAGAgent
    except ImportError as e:
        print(f"Error importing RAG agent: {e}")
        print("Please make sure all dependencies are installed by running:")
        print("python setup_rag.py")
        return
    
    # Try to load configuration
    try:
        import config
        api_key = config.OPENROUTER_API_KEY
        model_name = getattr(config, 'MODEL_NAME', 'anthropic/claude-3.5-haiku')
    except ImportError:
        print("config.py not found. Using demo mode with placeholder API key.")
        print("To fully test the agent, please:")
        print("1. Copy config_template.py to config.py")
        print("2. Add your OpenRouter API key")
        api_key = "demo-key"
        model_name = 'anthropic/claude-3.5-haiku'
    
    if api_key == "your-openrouter-api-key-here" or api_key == "demo-key":
        print("\n" + "="*60)
        print("DEMO MODE - API calls will not work")
        print("="*60)
        print("To enable full functionality:")
        print("1. Get API key from https://openrouter.ai/")
        print("2. Copy config_template.py to config.py") 
        print("3. Add your API key to config.py")
        print("="*60 + "\n")
        
        # Run in demo mode without API calls
        demo_mode = True
    else:
        demo_mode = False
    
    # Example queries to test
    example_queries = [
        "Letstalk支援哪些系統？",
        "忘記密碼怎麼辦？",
        "如何切換帳號？",
        "如何聯絡客服？",
        "蘋果手機安裝不了",
    ]
    
    print("RAG Agent Demo")
    print("="*50)
    
    if not demo_mode:
        # Initialize agent
        agent = RAGAgent(api_key, model_name)
        
        # Load data and create embeddings
        csv_files = [
            "AmazonBedrock_20250217FAQ.csv",
            "AmazonBedrock_20250217additional.csv",
            "AmazonBedrock_2025021404.csv"
        ]
        
        if not agent.load_embeddings():
            print("Creating embeddings...")
            agent.load_multiple_csv_files(csv_files)
            if agent.documents:
                agent.create_embeddings()
            else:
                print("No CSV files found for demo.")
                return
        
        print(f"Loaded {len(agent.documents)} documents")
        print("\nTesting example queries:")
        print("-" * 30)
        
        for query in example_queries:
            print(f"\nQ: {query}")
            try:
                response = agent.chat(query)
                print(f"A: {response}")
            except Exception as e:
                print(f"Error: {e}")
            print("-" * 30)
    
    else:
        # Demo mode - show what would happen
        print("In full mode, the agent would:")
        print("1. Load FAQ data from CSV files")
        print("2. Create embeddings for semantic search")
        print("3. Answer user queries using RAG + Claude 3.5 Haiku")
        print("\nExample queries that could be answered:")
        for i, query in enumerate(example_queries, 1):
            print(f"{i}. {query}")
    
    print(f"\n{'='*50}")
    print("Demo completed!")
    print("To run the interactive agent: python rag_agent.py")

if __name__ == "__main__":
    demo_rag_agent()
