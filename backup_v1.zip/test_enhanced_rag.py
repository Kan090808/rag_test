#!/usr/bin/env python3
"""
Test script for enhanced RAG functionality
Tests query expansion and multi-stage retrieval
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from rag_agent import RAGAgent
import config

def test_enhanced_rag():
    """Test the enhanced RAG functionality"""
    
    print("=" * 60)
    print("Testing Enhanced RAG with Query Expansion and Multi-stage Retrieval")
    print("=" * 60)
    
    # Initialize RAG agent
    agent = RAGAgent(
        openrouter_api_key=config.OPENROUTER_API_KEY,
        model_name=config.MODEL_NAME,
        max_tokens=config.MAX_TOKENS,
        temperature=config.TEMPERATURE,
        log_file="test_enhanced_rag_log.txt",
        system_prompt=config.SYSTEM_PROMPT
    )
    agent.default_top_k = config.TOP_K_DOCUMENTS
    
    # Load embeddings or create new ones
    if not agent.load_embeddings():
        print("Creating new embeddings...")
        # Load data
        csv_files = getattr(config, 'CSV_FILES', [])
        txt_files = getattr(config, 'TXT_FILES', [])
        agent.load_multiple_files(csv_files, txt_files)
        
        if not agent.documents:
            print("No documents loaded. Please check your data files.")
            return
        
        agent.create_embeddings()
    
    print(f"\nLoaded {len(agent.documents)} documents")
    print("\n" + "=" * 40)
    print("Testing Different Query Types")
    print("=" * 40)
    
    # Test cases for different query lengths and types
    test_queries = [
        "退",        # Very short query (1 character)
        "退貨",      # Short query (2 characters)
        "退貨流程",   # Medium query
        "如何申請退貨", # Longer query
        "會員",      # Short query for expansion
        "付款方式",   # Medium query
        "配送時間要多久", # Natural question
    ]
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n--- Test {i}: '{query}' ---")
        print(f"Query length: {len(query)} characters")
        
        # Test query expansion
        expanded_query = agent.expand_query(query)
        if expanded_query != query:
            print(f"Expanded query: {expanded_query}")
        else:
            print("Query not expanded")
        
        # Test retrieval
        relevant_docs = agent.retrieve_relevant_documents(query, top_k=3)
        
        print(f"Found {len(relevant_docs)} relevant documents:")
        for j, doc in enumerate(relevant_docs, 1):
            print(f"  {j}. Similarity: {doc['similarity']:.4f}")
            print(f"     Question: {doc['metadata']['question'][:50]}...")
            
        print("-" * 50)
    
    # Test the complete chat functionality
    print("\n" + "=" * 40)
    print("Testing Complete Chat Functionality")
    print("=" * 40)
    
    chat_test_queries = [
        "退",
        "退貨怎麼辦",
        "會員註冊",
    ]
    
    for query in chat_test_queries:
        print(f"\nChat Test: '{query}'")
        response = agent.chat(query)
        print(f"Response: {response}")
        print("-" * 50)
    
    print("\n" + "=" * 60)
    print("Enhanced RAG Testing Complete!")
    print("Check 'test_enhanced_rag_log.txt' for detailed logs.")
    print("=" * 60)

if __name__ == "__main__":
    test_enhanced_rag()
