#!/usr/bin/env python3
"""
Simple test to check RAG agent logging functionality
"""

from rag_agent import RAGAgent
import config

def test_rag_agent_logging():
    """Test RAG agent logging functionality"""
    
    print("Creating RAG agent with logging...")
    
    # Create agent with logging
    agent = RAGAgent(
        "dummy-key",  # Using dummy key for testing
        config.MODEL_NAME,
        config.MAX_TOKENS,
        config.TEMPERATURE,
        "test_agent_log.txt"  # Custom log file for testing
    )
    agent.default_top_k = config.TOP_K_DOCUMENTS
    
    print("RAG agent created successfully!")
    print("Check test_agent_log.txt for logging output")

if __name__ == "__main__":
    test_rag_agent_logging()
