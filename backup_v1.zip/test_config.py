#!/usr/bin/env python3
"""
Test script to verify RAG agent uses configuration values
"""

import sys
sys.path.append('.')

from rag_agent import RAGAgent
import config

def test_rag_agent_config():
    """Test that RAG agent uses config values properly"""
    
    print("Testing RAG agent configuration usage...")
    
    # Create RAG agent with config values
    agent = RAGAgent(
        "dummy-key",  # Using dummy key for testing
        config.MODEL_NAME,
        config.MAX_TOKENS,
        config.TEMPERATURE
    )
    agent.default_top_k = config.TOP_K_DOCUMENTS
    
    # Test configuration values
    print(f"Model Name: {agent.model_name}")
    print(f"Max Tokens: {agent.max_tokens}")
    print(f"Temperature: {agent.temperature}")
    print(f"Default Top K: {agent.default_top_k}")
    
    # Verify values match config
    assert agent.model_name == config.MODEL_NAME
    assert agent.max_tokens == config.MAX_TOKENS
    assert agent.temperature == config.TEMPERATURE
    assert agent.default_top_k == config.TOP_K_DOCUMENTS
    
    print("\n✅ All configuration values are correctly loaded!")
    print(f"✅ TOP_K_DOCUMENTS is set to: {config.TOP_K_DOCUMENTS}")

if __name__ == "__main__":
    test_rag_agent_config()
