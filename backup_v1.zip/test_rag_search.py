#!/usr/bin/env python3
"""
Simple test to demonstrate RAG functionality without API calls
This shows how the semantic search part works
"""

import pandas as pd
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import json
from datetime import datetime

# Try to load configuration
try:
    import config
    TOP_K_DOCUMENTS = getattr(config, 'TOP_K_DOCUMENTS', 3)
    LOG_FILE = getattr(config, 'LOG_FILE', 'log.txt')
    CSV_FILES = getattr(config, 'CSV_FILES', [
        "AmazonBedrock_20250217FAQ.csv",
        "AmazonBedrock_20250217additional.csv",
        "AmazonBedrock_2025021404.csv"
    ])
    TXT_FILES = getattr(config, 'TXT_FILES', [])
except ImportError:
    print("config.py not found. Using default values.")
    TOP_K_DOCUMENTS = 3
    LOG_FILE = 'log.txt'
    CSV_FILES = [
        "AmazonBedrock_20250217FAQ.csv",
        "AmazonBedrock_20250217additional.csv",
        "AmazonBedrock_2025021404.csv"
    ]
    TXT_FILES = []

def log_test_operation(operation_type: str, operation: str, details: dict):
    """Log test operation details to the same log file as RAG agent"""
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = {
            "timestamp": timestamp,
            "type": operation_type,
            "operation": operation,
            "details": details
        }
        
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"\n{json.dumps(log_entry, ensure_ascii=False, indent=2)}\n")
            f.write("-" * 80 + "\n")
    except Exception as e:
        print(f"Warning: Could not write to log file: {e}")

def test_rag_functionality():
    """Test the RAG functionality without API calls"""
    
    # Initialize logging
    log_test_operation("TEST_START", "Starting RAG functionality test", {
        "top_k_documents": TOP_K_DOCUMENTS,
        "csv_files": CSV_FILES,
        "txt_files": TXT_FILES
    })
    
    print("Loading sentence transformer model...")
    model = SentenceTransformer('all-MiniLM-L6-v2')
    
    # Load CSV data
    print("Loading CSV data...")
    csv_files = CSV_FILES
    
    documents = []
    metadata = []
    
    # Load CSV files
    for csv_file in csv_files:
        try:
            df = pd.read_csv(csv_file)
            for index, row in df.iterrows():
                if pd.notna(row.get('問題', '')) and pd.notna(row.get('答案', '')):
                    content = f"問題：{row['問題']}\n答案：{row['答案']}"
                    documents.append(content)
                    metadata.append({
                        'source': csv_file,
                        'index': index,
                        'question': row['問題'],
                        'answer': row['答案']
                    })
        except Exception as e:
            log_test_operation("ERROR", f"Failed to load data", {"error": str(e)})
            print(f"Error loading data: {e}")
            continue
    
    # Load TXT files
    if TXT_FILES:
        print("Loading TXT data...")
        for txt_file in TXT_FILES:
            try:
                with open(txt_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Split by Q: to get each Q&A pair
                lines = content.split('\n')
                current_qa = ""
                qa_count = 0
                
                for line in lines:
                    line = line.strip()
                    if line.startswith('Q:'):
                        # If we have a previous Q&A pair, process it
                        if current_qa:
                            if ' A:' in current_qa:
                                question_part, answer_part = current_qa.split(' A:', 1)
                                question = question_part.replace('Q:', '').strip()
                                answer = answer_part.strip()
                                
                                if question and answer:
                                    content_formatted = f"問題：{question}\n答案：{answer}"
                                    documents.append(content_formatted)
                                    metadata.append({
                                        'source': txt_file,
                                        'index': qa_count,
                                        'question': question,
                                        'answer': answer
                                    })
                                    qa_count += 1
                        # Start new Q&A pair
                        current_qa = line
                    elif line and current_qa:
                        # Continue current Q&A pair
                        current_qa += " " + line
                
                # Process the last Q&A pair
                if current_qa and ' A:' in current_qa:
                    question_part, answer_part = current_qa.split(' A:', 1)
                    question = question_part.replace('Q:', '').strip()
                    answer = answer_part.strip()
                    
                    if question and answer:
                        content_formatted = f"問題：{question}\n答案：{answer}"
                        documents.append(content_formatted)
                        metadata.append({
                            'source': txt_file,
                            'index': qa_count,
                            'question': question,
                            'answer': answer
                        })
                        qa_count += 1
                
                print(f"Loaded {qa_count} Q&A pairs from {txt_file}")
                
            except Exception as e:
                print(f"Error loading {txt_file}: {e}")
                continue
    
    print(f"Loaded {len(documents)} documents")
    
    if not documents:
        print("No documents found!")
        return
    
    # Create embeddings
    print("Creating embeddings...")
    embeddings = model.encode(documents)
    
    # Test queries
    test_queries = [
        "Letstalk支援系統",
        "忘記密碼",
        "如何切換帳號"
    ]
    
    print("\n" + "="*60)
    print("Testing semantic search:")
    print("="*60)
    
    for query in test_queries:
        print(f"\n查詢: {query}")
        print("-" * 40)
        
        # Create query embedding
        query_embedding = model.encode([query])
        
        # Calculate similarities
        similarities = cosine_similarity(query_embedding, embeddings)[0]
        
        # Get top k most similar documents
        top_indices = np.argsort(similarities)[::-1][:TOP_K_DOCUMENTS]
        
        # Prepare search results for logging
        search_results = []
        for i, idx in enumerate(top_indices, 1):
            sim_score = similarities[idx]
            meta = metadata[idx]
            search_results.append({
                'rank': i,
                'similarity_score': float(sim_score),
                'question': meta['question'],
                'answer': meta['answer'],
                'source': meta['source']
            })
            
            print(f"{i}. 相似度: {sim_score:.4f}")
            print(f"   問題: {meta['question']}")
            print(f"   答案: {meta['answer']}")
            print(f"   來源: {meta['source']}")
            print()
        
        # Log the search operation
        log_test_operation("TEST_SEARCH", "Semantic search test", {
            "query": query,
            "top_k": TOP_K_DOCUMENTS,
            "total_documents": len(documents),
            "results": search_results
        })
    
    print("="*60)
    print("Test completed!")
    print("Note: In full mode, these results would be sent to Claude 3.5 Haiku for final answer generation.")
    
    # Log test completion
    log_test_operation("TEST_COMPLETE", "RAG search test completed", {
        "total_documents": len(documents),
        "test_queries": len(test_queries),
        "top_k_used": TOP_K_DOCUMENTS
    })

if __name__ == "__main__":
    test_rag_functionality()
