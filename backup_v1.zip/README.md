# RAG Agent with OpenRouter Claude 3.5 Haiku

A Python-based Retrieval-Augmented Generation (RAG) agent that uses semantic search to find relevant information from CSV files and generates responses using OpenRouter's Claude 3.5 Haiku model.

## Features

- 🔍 **Semantic Search**: Uses sentence transformers to find relevant information
- 🤖 **AI-Powered Responses**: Generates answers using Claude 3.5 Haiku via OpenRouter
- 📊 **CSV Data Support**: Loads FAQ data from CSV files
- 💾 **Embedding Cache**: Saves embeddings to avoid recomputation
- 🗣️ **Interactive Chat**: Command-line interface for conversations

## Quick Start

### 1. Install Dependencies

```bash
python setup_rag.py
```

Or manually install:
```bash
pip install -r requirements.txt
```

### 2. Configure API Key

1. Get your OpenRouter API key from [https://openrouter.ai/](https://openrouter.ai/)
2. Copy the configuration template:
   ```bash
   cp config_template.py config.py
   ```
3. Edit `config.py` and add your API key:
   ```python
   OPENROUTER_API_KEY = "your-actual-api-key-here"
   ```

### 3. Run the Agent

```bash
python rag_agent.py
```

Or try the demo:
```bash
python demo_rag.py
```

## File Structure

```
├── rag_agent.py           # Main RAG agent implementation
├── config_template.py     # Configuration template
├── requirements.txt       # Python dependencies
├── setup_rag.py          # Setup script
├── demo_rag.py           # Demo script
├── README.md             # This file
├── AmazonBedrock_*.csv   # FAQ data files
└── embeddings.pkl        # Cached embeddings (created automatically)
```

## How It Works

1. **Data Loading**: Loads FAQ data from CSV files
2. **Embedding Creation**: Creates semantic embeddings using sentence transformers
3. **Query Processing**: When user asks a question:
   - Creates embedding for the query
   - Finds most similar documents using cosine similarity
   - Sends relevant context + query to Claude 3.5 Haiku
   - Returns generated response

## Configuration Options

In `config.py`, you can customize:

```python
# API Configuration
OPENROUTER_API_KEY = "your-key"
MODEL_NAME = "anthropic/claude-3.5-haiku"  # Or other OpenRouter models

# RAG Parameters
TOP_K_DOCUMENTS = 3      # Number of relevant docs to retrieve
MAX_TOKENS = 1000        # Response length limit
TEMPERATURE = 0.7        # Response creativity (0-1)

# Data Files
CSV_FILES = [
    "AmazonBedrock_20250217FAQ.csv",
    "AmazonBedrock_20250217additional.csv",
    "AmazonBedrock_2025021404.csv"
]
```

## CSV Data Format

Your CSV files should have columns for questions and answers:

```csv
問題,答案
Letstalk支援系統？,"Letstalk 目前支援..."
忘記密碼怎麼辦？,請確認您目前使用的...
```

## Usage Examples

### Interactive Mode
```bash
python rag_agent.py
```

### Programmatic Usage
```python
from rag_agent import RAGAgent

agent = RAGAgent("your-api-key")
agent.load_multiple_csv_files(["data.csv"])
agent.create_embeddings()

response = agent.chat("How do I reset my password?")
print(response)
```

## Troubleshooting

### Common Issues

1. **Import Errors**: Run `python setup_rag.py` to install dependencies
2. **API Key Issues**: Make sure your OpenRouter API key is valid and properly set in `config.py`
3. **No CSV Files**: Ensure your CSV files are in the correct directory
4. **Empty Responses**: Check if your CSV files have the correct column names

### Dependencies

- `numpy`: Numerical computations
- `pandas`: CSV file handling
- `sentence-transformers`: Semantic embeddings
- `scikit-learn`: Similarity calculations
- `requests`: API calls to OpenRouter
- `torch`: Required by sentence-transformers

## License

This project is open source. Feel free to modify and distribute.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## Support

If you encounter issues:
1. Check the troubleshooting section
2. Ensure all dependencies are installed
3. Verify your API key is correct
4. Check that CSV files are in the proper format
